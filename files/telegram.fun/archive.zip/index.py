import webview

webview.create_window('Telegram Web', 'https://web.telegram.org')

webview.start()

import webbrowser

url = ""

webbrowser.open(url)
